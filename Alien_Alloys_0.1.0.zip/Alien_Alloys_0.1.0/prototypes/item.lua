data:extend({

{
    type = "item",
    name = "alloy-furnace",
    icon = "__Alien_Alloys__/graphics/icons/alloy-furnace.png",
    flags = {"goes-to-quickbar"},
    subgroup = "smelting-machine",
    order = "d[alloy-furnace]",
    place_result = "alloy-furnace",
    stack_size = 50
},
{
    type = "item",
    name = "alien-alloy",
    icon = "__Alien_Alloys__/graphics/icons/alien-alloy.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "raw-material",
    order = "c[alien-alloy]",
    stack_size = 100
  }
        
})