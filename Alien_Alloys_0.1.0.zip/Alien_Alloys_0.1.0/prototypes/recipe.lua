data:extend({

{
    type = "recipe",
    name = "alloy-furnace",
    energy_required = 20,
    enabled = true,
    ingredients =
    {
      {type="item", name="electric-furnace", amount=1},
      {type="item", name="assembling-machine-3", amount=2},
      {type="item", name="chemical-plant", amount=1}                
    },
    result = "alloy-furnace"
},
{
    type = "recipe",
    name = "alien-alloy",
    category = "crafting-with-fluid",
    energy_required = 10,
    enabled = true,
    ingredients =
    {
      {type="item", name="steel-plate", amount=10},
      {type="item", name="copper-plate", amount=5},
      {type="item", name="alien-artifact", amount=5},
      {type="fluid", name="lubricant", amount=5}
                
    },
    result = "alien-alloy"
  }
        
})