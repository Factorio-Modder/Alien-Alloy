data:extend({

{
    type = "technology",
    name = "alloy-processing",
    icon = "__base__/graphics/technology/steel-processing.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = {"alloy-furnace", "alien-alloy"}
        
      },
    },
    prerequisites = {"steel-processing", "alien-technology"},
    unit =
    {
      count = 100,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"alien-science-pack", 1}
      },
      time = 60
    },
    order = "c-b"
  }

})